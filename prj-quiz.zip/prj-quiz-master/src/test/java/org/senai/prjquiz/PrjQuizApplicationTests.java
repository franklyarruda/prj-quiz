package org.senai.prjquiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
